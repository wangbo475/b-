# B站 & 快手视频下载器（安卓原生独立版）

本项目是一个完整的原生 Android（Kotlin + Material 3）独立应用工程，基于 [youtubedl-android](https://github.com/yausername/youtubedl-android)（`io.github.junkfood02.youtubedl-android`）将 Python 运行时、[yt-dlp](https://github.com/yt-dlp/yt-dlp) 与 [FFmpeg](https://ffmpeg.org/download.html) 直接内置于 APK 中，安装到安卓手机后无需 Termux 或任何外部依赖即可独立运行。

## 核心特性

- **完全独立运行**：内置 Python + yt-dlp + FFmpeg，直接支持 B 站 1080P+ 音视频合并与 MP3 音频提取。
- **支持系统分享直达**：在 B 站或快手 App 内点击「分享」→ 选择本软件，自动提取链接。
- **智能链接清洗**：支持直接粘贴整段分享文案、`b23.tv` / `v.kuaishou.com` 短链及独立 BV/av 号，支持多行批量下载。
- **适配 Android 10–14 分区存储**：自动将成品保存至手机公共目录 `Download/BiliKuaishou/`，相册与文件管理器可直接查看。
- **应用内一键更新解析内核**：内置「更新内核」按钮，平台接口变动时无需重新打包 APK。

## 如何生成可安装的 APK

### 方式一：免装 Android Studio，使用 GitHub Actions 云端自动打包（推荐）

1. 在 GitHub 新建一个仓库（公开或私有均可），将解压后的本目录所有文件上传到仓库根目录（包含 `.github/workflows/build-apk.yml`）。
2. 进入仓库的 **Actions** 页面，等待 **Build Android APK** 自动运行完成（也可手动点击 **Run workflow**）。
3. 在构建结果的 **Artifacts** 中下载 `BiliKuaishouDownloader-APK`，解压出 `app-debug.apk` 发送到安卓手机安装即可。

### 方式二：使用 Android Studio 本地打包

1. 安装 Android Studio 并打开解压后的 `BiliKuaishouAndroid` 文件夹。
2. 等待 Gradle 自动同步依赖（依赖均来自 Google 与 Maven Central，无需额外配置）。
3. 点击顶部菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**，生成的安装包位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 注意事项

- 首次打开 App 时会自动初始化内置的 Python 与 FFmpeg 环境（耗时约数秒）。
- 如需下载 B 站 1080P+/大会员画质或应对快手风控验证，可在界面中点击「导入 cookies.txt」导入 Netscape 格式 Cookie 文件。
- 请仅用于个人学习、备份自有作品或已获得合法授权的内容。
