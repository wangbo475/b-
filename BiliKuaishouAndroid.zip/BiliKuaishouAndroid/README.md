# B站 & 快手视频下载器（安卓原生独立版 v1.2.0）

- **B 站下载与字幕提取**：基于 [youtubedl-android](https://github.com/yausername/youtubedl-android) 内置 [yt-dlp](https://github.com/yt-dlp/yt-dlp) + [FFmpeg](https://ffmpeg.org/download.html)，支持 1080P+ 音视频合并、MP3 提取、**仅提取 SRT 字幕**以及**下载视频同步保存 SRT 字幕**（提取 B 站 CC/AI 字幕建议导入已登录的 `cookies.txt`）。
- **快手下载**：内置原生双引擎解析器（HTTP 重定向解析 + 内置 WebView 视频流嗅探），并支持尝试保存作品文案 `.txt`。
- **体积极致优化**：v1.2.0 默认仅打包 `arm64-v8a` 架构，APK 体积减半，避免手机下载构建包断流。
