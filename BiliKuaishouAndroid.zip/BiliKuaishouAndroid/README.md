# B站 & 快手视频下载器（安卓原生独立版 v1.1.0）

- **B 站下载**：基于 [youtubedl-android](https://github.com/yausername/youtubedl-android) 内置 [yt-dlp](https://github.com/yt-dlp/yt-dlp) + [FFmpeg](https://ffmpeg.org/download.html)，支持 1080P+ 音视频合并、多 P 合集与 MP3 提取。
- **快手下载**：内置原生双引擎解析器（高速 HTTP 重定向解析 + 内置 Chromium WebView 视频流嗅探），无需依赖 yt-dlp，支持 `v.kuaishou.com` 短链直下 MP4。

## 更新打包方式（GitHub 手机端）

只需在你的 GitHub 仓库中重新上传新版 `BiliKuaishouAndroid.zip` 覆盖旧文件，GitHub Actions 会自动重新打包出新版 `app-debug.apk`，覆盖安装即可。
