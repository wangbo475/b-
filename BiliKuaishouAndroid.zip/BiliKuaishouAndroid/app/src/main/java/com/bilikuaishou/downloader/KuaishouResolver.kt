package com.bilikuaishou.downloader

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

data class ResolvedKuaishouMedia(
    val videoUrl: String,
    val title: String,
    val referer: String,
    val cookieHeader: String?,
)

/**
 * 原生快手视频解析与下载器（不依赖 yt-dlp）：
 * 1. 先尝试高速 HTTP 重定向与页面 JSON/HTML 解析；
 * 2. 若快手页面需要 JS 渲染或风控签名，自动启用内置 Chromium WebView 嗅探真实 MP4 流地址；
 * 3. 使用流式下载直接保存为 MP4，并实时回调进度。
 */
object KuaishouResolver {
    private const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    private val videoUrlPatterns = listOf(
        Regex("\"mainMvUrls\"\\s*:\\s*\\[\\s*\\{[^\\}]*?\"url\"\\s*:\\s*\"(https?:\\\\?/\\\\?/[^\"]+?)\""),
        Regex("\"photoUrl\"\\s*:\\s*\"(https?:\\\\?/\\\\?/[^\"]+?)\""),
        Regex("\"playUrl\"\\s*:\\s*\"(https?:\\\\?/\\\\?/[^\"]+?)\""),
        Regex("\"srcNoMark\"\\s*:\\s*\"(https?:\\\\?/\\\\?/[^\"]+?)\""),
        Regex("<video[^>]+src=[\"'](https?://[^\"']+?)[\"']", RegexOption.IGNORE_CASE),
        Regex("(https?://[a-zA-Z0-9._-]+\\.(?:kwimgs|kwaicdn|yximgs)\\.com/[^\"'\\s<>]+?\\.mp4[^\"'\\s<>]*)"),
    )

    private val titlePatterns = listOf(
        Regex("\"caption\"\\s*:\\s*\"([^\"\\\\]{2,80})\""),
        Regex("<title>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)),
    )

    suspend fun resolve(
        context: Context,
        shareUrl: String,
        onLog: (String) -> Unit,
    ): ResolvedKuaishouMedia {
        onLog("[快手解析] 正在尝试高速解析短链...")
        val httpResult = tryResolveViaHttp(shareUrl, onLog)
        if (httpResult != null) {
            onLog("[快手解析] 高速解析成功，已获取视频直链。")
            return httpResult
        }

        onLog("[快手解析] 页面需动态渲染，正在启动内置 WebView 嗅探视频流...")
        val webResult = resolveViaWebView(context, shareUrl, onLog)
        if (webResult != null) {
            onLog("[快手解析] WebView 嗅探成功，已捕获高清视频流。")
            return webResult
        }

        throw IllegalStateException("未能从快手页面捕获视频流，请确认链接有效且未触发滑块验证")
    }

    private suspend fun tryResolveViaHttp(
        shareUrl: String,
        onLog: (String) -> Unit,
    ): ResolvedKuaishouMedia? = withContext(Dispatchers.IO) {
        try {
            val (finalUrl, html, cookies) = fetchWithRedirects(shareUrl)
            val videoUrl = extractVideoUrlFromHtml(html)
            if (videoUrl != null) {
                val title = extractTitleFromHtml(html)
                return@withContext ResolvedKuaishouMedia(
                    videoUrl = videoUrl,
                    title = title,
                    referer = finalUrl,
                    cookieHeader = cookies.ifBlank { null },
                )
            }
            onLog("[快手解析] 重定向地址：$finalUrl（未直接发现静态直链，转入 WebView）")
            null
        } catch (e: Exception) {
            onLog("[快手解析] HTTP 预解析跳过：${e.message}")
            null
        }
    }

    private fun fetchWithRedirects(startUrl: String): Triple<String, String, String> {
        var currentUrl = startUrl
        val cookieList = mutableListOf<String>()
        var html = ""

        repeat(6) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 15000
                readTimeout = 15000
                setRequestProperty("User-Agent", MOBILE_UA)
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9")
                if (cookieList.isNotEmpty()) {
                    setRequestProperty("Cookie", cookieList.joinToString("; "))
                }
            }

            try {
                conn.connect()
                conn.headerFields["Set-Cookie"]?.forEach { rawCookie ->
                    val pair = rawCookie.substringBefore(";").trim()
                    if (pair.isNotEmpty()) cookieList.add(pair)
                }

                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: return Triple(currentUrl, "", cookieList.joinToString("; "))
                    currentUrl = URL(URL(currentUrl), location).toString()
                } else {
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    html = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    return Triple(currentUrl, html, cookieList.joinToString("; "))
                }
            } finally {
                conn.disconnect()
            }
        }
        return Triple(currentUrl, html, cookieList.joinToString("; "))
    }

    private fun unescapeJsonUrl(raw: String): String {
        return raw
            .replace("\\u002F", "/")
            .replace("\\u0026", "&")
            .replace("\\/", "/")
            .replace("&amp;", "&")
            .trim()
    }

    private fun isLikelyVideoStream(url: String): Boolean {
        val lower = url.lowercase()
        if (!lower.startsWith("http")) return false
        if (lower.contains(".jpg") || lower.contains(".jpeg") || lower.contains(".png") || lower.contains(".webp")) {
            return false
        }
        return lower.contains(".mp4") ||
            lower.contains("kwimgs.com") && lower.contains("upic") ||
            lower.contains("kwaicdn.com") && (lower.contains("mp4") || lower.contains("upic")) ||
            lower.contains("yximgs.com") && lower.contains("mp4")
    }

    private fun extractVideoUrlFromHtml(html: String): String? {
        for (regex in videoUrlPatterns) {
            val match = regex.find(html) ?: continue
            val candidate = unescapeJsonUrl(match.groupValues[1])
            if (isLikelyVideoStream(candidate)) {
                return candidate
            }
        }
        return null
    }

    private fun extractTitleFromHtml(html: String): String {
        for (regex in titlePatterns) {
            val raw = regex.find(html)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            if (raw.isNotBlank() && !raw.equals("快手", ignoreCase = true)) {
                return sanitizeFilename(raw)
            }
        }
        return "kuaishou_${System.currentTimeMillis()}"
    }

    private fun sanitizeFilename(raw: String): String {
        val cleaned = raw
            .replace(Regex("[\\\\/:*?\"<>|\\r\\n\\t]+"), "_")
            .trim()
            .take(60)
        return cleaned.ifBlank { "kuaishou_${System.currentTimeMillis()}" }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun resolveViaWebView(
        context: Context,
        shareUrl: String,
        onLog: (String) -> Unit,
    ): ResolvedKuaishouMedia? = withTimeoutOrNull(25_000L) {
        suspendCancellableCoroutine { cont ->
            val mainHandler = Handler(Looper.getMainLooper())
            val finished = AtomicBoolean(false)
            var webViewRef: WebView? = null

            fun finishWith(result: ResolvedKuaishouMedia?) {
                if (finished.compareAndSet(false, true)) {
                    mainHandler.post {
                        try {
                            webViewRef?.stopLoading()
                            webViewRef?.destroy()
                        } catch (_: Exception) {
                        }
                        webViewRef = null
                        if (cont.isActive) {
                            cont.resume(result)
                        }
                    }
                }
            }

            mainHandler.post {
                val webView = WebView(context.applicationContext)
                webViewRef = webView
                with(webView.settings) {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    userAgentString = MOBILE_UA
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                CookieManager.getInstance().setAcceptCookie(true)

                val pollJs = "(function(){var v=document.querySelector('video');if(v){var src=v.currentSrc||v.src;if(!src){var s=v.querySelector('source');if(s)src=s.src;}if(src&&src.indexOf('http')===0){return JSON.stringify({url:src,title:document.title||''});}}return '';})();"

                webView.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?,
                    ): WebResourceResponse? {
                        val reqUrl = request?.url?.toString().orEmpty()
                        if (!finished.get() && isLikelyVideoStream(reqUrl)) {
                            val cookie = CookieManager.getInstance().getCookie(reqUrl)
                            val referer = request?.requestHeaders?.get("Referer") ?: shareUrl
                            finishWith(
                                ResolvedKuaishouMedia(
                                    videoUrl = reqUrl,
                                    title = "kuaishou_${System.currentTimeMillis()}",
                                    referer = referer,
                                    cookieHeader = cookie,
                                )
                            )
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (finished.get()) return
                        // 页面加载后轮询 DOM 中的 <video> 标签
                        val delays = listOf(800L, 2000L, 4000L, 7000L)
                        for (delay in delays) {
                            mainHandler.postDelayed({
                                if (finished.get()) return@postDelayed
                                view?.evaluateJavascript(pollJs) { rawResult ->
                                    if (finished.get() || rawResult.isNullOrBlank() || rawResult == "\"\"" || rawResult == "null") {
                                        return@evaluateJavascript
                                    }
                                    val unquoted = rawResult
                                        .removeSurrounding("\"")
                                        .replace("\\\"", "\"")
                                        .replace("\\\\", "\\")
                                    val urlMatch = Regex("\"url\"\\s*:\\s*\"(https?://[^\"]+)\"").find(unquoted)
                                    val titleMatch = Regex("\"title\"\\s*:\\s*\"([^\"]*)\"").find(unquoted)
                                    val foundUrl = urlMatch?.groupValues?.getOrNull(1)?.let { unescapeJsonUrl(it) }
                                    if (!foundUrl.isNullOrBlank() && isLikelyVideoStream(foundUrl)) {
                                        val title = titleMatch?.groupValues?.getOrNull(1)
                                            ?.takeIf { it.isNotBlank() }
                                            ?.let { sanitizeFilename(it) }
                                            ?: "kuaishou_${System.currentTimeMillis()}"
                                        val cookie = CookieManager.getInstance().getCookie(url ?: shareUrl)
                                        finishWith(
                                            ResolvedKuaishouMedia(
                                                videoUrl = foundUrl,
                                                title = title,
                                                referer = url ?: shareUrl,
                                                cookieHeader = cookie,
                                            )
                                        )
                                    }
                                }
                            }, delay)
                        }
                    }
                }

                onLog("[快手解析] 正在加载快手页面以捕获视频直链...")
                webView.loadUrl(shareUrl)
            }

            cont.invokeOnCancellation {
                finishWith(null)
            }
        }
    }

    suspend fun downloadDirectMp4(
        media: ResolvedKuaishouMedia,
        destFile: File,
        isCancelled: () -> Boolean,
        onProgress: (progress: Float, etaSeconds: Long) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val conn = (URL(media.videoUrl).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 20000
            readTimeout = 30000
            setRequestProperty("User-Agent", MOBILE_UA)
            setRequestProperty("Referer", media.referer)
            if (!media.cookieHeader.isNullOrBlank()) {
                setRequestProperty("Cookie", media.cookieHeader)
            }
        }

        try {
            conn.connect()
            val code = conn.responseCode
            if (code !in 200..299) {
                throw IllegalStateException("视频流下载失败，HTTP 状态码：$code")
            }

            val totalBytes = conn.contentLengthLong
            var downloadedBytes = 0L
            val startTime = System.currentTimeMillis()
            val buffer = ByteArray(16 * 1024)

            conn.inputStream.use { input ->
                FileOutputStream(destFile).use { output ->
                    while (true) {
                        if (isCancelled()) {
                            throw IllegalStateException("任务已取消")
                        }
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        downloadedBytes += read

                        if (totalBytes > 0L) {
                            val progress = (downloadedBytes * 100f / totalBytes).coerceIn(0f, 100f)
                            val elapsedSec = ((System.currentTimeMillis() - startTime) / 1000.0).coerceAtLeast(0.1)
                            val speed = downloadedBytes / elapsedSec
                            val eta = if (speed > 0) ((totalBytes - downloadedBytes) / speed).toLong() else -1L
                            onProgress(progress, eta)
                        }
                    }
                }
            }
            onProgress(100f, 0L)
        } finally {
            conn.disconnect()
        }
    }
}
