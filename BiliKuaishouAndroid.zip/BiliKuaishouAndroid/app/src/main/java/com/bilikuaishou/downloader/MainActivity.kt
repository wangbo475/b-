package com.bilikuaishou.downloader

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.bilikuaishou.downloader.databinding.ActivityMainBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File
import java.nio.charset.Charset

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var downloadJob: Job? = null
    private var localCookiePath: String? = null

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startDownload()
        } else {
            Toast.makeText(this, "需要存储权限才能保存到手机下载目录", Toast.LENGTH_SHORT).show()
        }
    }

    private val cookieFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            importCookieFile(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        initEngine()
        handleIncomingShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingShareIntent(intent)
    }

    private fun setupListeners() {
        binding.btnPaste.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            if (text.isBlank()) {
                Toast.makeText(this, "剪贴板为空", Toast.LENGTH_SHORT).show()
            } else {
                val current = binding.etLinks.text?.toString().orEmpty().trim()
                val merged = if (current.isEmpty()) text else "$current\n$text"
                binding.etLinks.setText(merged)
            }
        }

        binding.btnClean.setOnClickListener {
            val links = LinkParser.extractLinks(binding.etLinks.text?.toString().orEmpty())
            if (links.isEmpty()) {
                Toast.makeText(this, "未识别到有效链接或 BV/av 号", Toast.LENGTH_SHORT).show()
            } else {
                binding.etLinks.setText(links.joinToString("\n") { it.url })
                appendLog("已提取 ${links.size} 条链接：${links.joinToString("、") { it.platformName }}")
            }
        }

        binding.btnClear.setOnClickListener {
            binding.etLinks.setText("")
        }

        binding.btnImportCookie.setOnClickListener {
            cookieFileLauncher.launch(arrayOf("text/plain", "*/*"))
        }

        binding.btnClearCookie.setOnClickListener {
            localCookiePath = null
            File(filesDir, "cookies.txt").delete()
            binding.tvCookieStatus.text = "Cookie：未导入（可选）"
            appendLog("已清除导入的 cookies.txt。")
        }

        binding.btnUpdateCore.setOnClickListener {
            updateYtDlpCore()
        }

        binding.btnDownload.setOnClickListener {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            } else {
                startDownload()
            }
        }

        binding.btnStop.setOnClickListener {
            DownloadManager.cancelActiveDownload()
            downloadJob?.cancel()
            setRunningState(false)
            binding.tvStatus.text = "已停止当前任务"
            appendLog("[提示] 用户已手动停止任务")
        }
    }

    private fun initEngine() {
        binding.tvStatus.text = "正在初始化下载内核..."
        setRunningState(true)
        lifecycleScope.launch {
            try {
                DownloadManager.ensureInitialized(this@MainActivity)
                binding.tvStatus.text = "内核已就绪，请粘贴 B 站或快手链接"
                appendLog("B 站引擎（yt-dlp + FFmpeg）与快手原生解析引擎已就绪。")
            } catch (e: Exception) {
                binding.tvStatus.text = "内核初始化失败"
                appendLog("[错误] 初始化失败：${e.message}")
            } finally {
                setRunningState(false)
            }
        }
    }

    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            if (sharedText.isNotBlank()) {
                val extracted = LinkParser.extractLinks(sharedText)
                val displayText = if (extracted.isNotEmpty()) {
                    extracted.joinToString("\n") { it.url }
                } else {
                    sharedText
                }
                binding.etLinks.setText(displayText)
                appendLog("已接收外部分享内容，点击「开始下载」即可保存。")
            }
        }
    }

    private fun importCookieFile(uri: Uri) {
        try {
            val rawBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("无法读取所选文件")
            val text = try {
                rawBytes.toString(Charsets.UTF_8)
            } catch (_: Exception) {
                String(rawBytes, Charset.forName("GBK"))
            }
            val cleaned = text.removePrefix("\uFEFF")
            val dest = File(filesDir, "cookies.txt")
            dest.writeText(cleaned, Charsets.UTF_8)
            localCookiePath = dest.absolutePath
            binding.tvCookieStatus.text = "Cookie：已导入 (UTF-8)"
            appendLog("已导入 cookies.txt（用于 B 站 1080P+/大会员画质）。")
        } catch (e: Exception) {
            Toast.makeText(this, "导入 Cookie 失败：${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateYtDlpCore() {
        setRunningState(true)
        binding.tvStatus.text = "正在检查并更新 yt-dlp 解析内核..."
        lifecycleScope.launch {
            try {
                val msg = DownloadManager.updateCore(this@MainActivity)
                binding.tvStatus.text = msg
                appendLog("[内核更新] $msg")
            } catch (e: Exception) {
                binding.tvStatus.text = "内核更新失败"
                appendLog("[内核更新失败] ${e.message}")
            } finally {
                setRunningState(false)
            }
        }
    }

    private fun selectedQuality(): QualityPreset {
        return when (binding.chipGroupQuality.checkedChipId) {
            R.id.chip1080p -> QualityPreset.HD_1080P
            R.id.chip720p -> QualityPreset.SD_720P
            R.id.chipMp3 -> QualityPreset.AUDIO_MP3
            else -> QualityPreset.BEST_MP4
        }
    }

    private fun startDownload() {
        val links = LinkParser.extractLinks(binding.etLinks.text?.toString().orEmpty())
        if (links.isEmpty()) {
            Toast.makeText(this, "请先输入至少一条 B 站或快手视频链接", Toast.LENGTH_SHORT).show()
            return
        }

        val quality = selectedQuality()
        val downloadPlaylist = binding.switchPlaylist.isChecked
        setRunningState(true)
        binding.progressBar.progress = 0

        downloadJob = lifecycleScope.launch {
            var successCount = 0
            var failCount = 0

            for ((index, item) in links.withIndex()) {
                val step = "${index + 1}/${links.size}"
                binding.tvStatus.text = "正在下载 ($step) [${item.platformName}]..."
                appendLog("\n>>> 开始下载 ($step) [${item.platformName}] ${item.url}")

                try {
                    val savedPaths = DownloadManager.downloadVideo(
                        context = this@MainActivity,
                        link = item,
                        quality = quality,
                        downloadPlaylist = downloadPlaylist,
                        cookieFilePath = localCookiePath,
                    ) { progress, etaSeconds, line ->
                        runOnUiThread {
                            if (progress >= 0f) {
                                binding.progressBar.progress = progress.toInt().coerceIn(0, 100)
                                val etaText = if (etaSeconds > 0) "${etaSeconds}s" else "--"
                                binding.tvProgressDetail.text = String.format("%.1f%%  |  预计剩余：%s", progress, etaText)
                            }
                            if (line.isNotBlank() && !line.startsWith("[download]")) {
                                appendLog(line)
                            }
                        }
                    }
                    successCount++
                    savedPaths.forEach { path ->
                        appendLog("[已保存] $path")
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failCount++
                    appendLog("[失败] (${item.platformName}) ${e.message}")
                    if (item.platformName == "B站") {
                        appendLog("提示：B 站高画质受限时可导入标准 Netscape 格式 cookies.txt 后重试。")
                    }
                }
            }

            val summary = "全部完成：成功 $successCount 个，失败 $failCount 个（保存至手机 Download/BiliKuaishou）"
            binding.tvStatus.text = summary
            appendLog("\n=== $summary ===")
            setRunningState(false)
        }
    }

    private fun setRunningState(running: Boolean) {
        binding.btnDownload.isEnabled = !running
        binding.btnUpdateCore.isEnabled = !running
        binding.btnStop.isEnabled = running
    }

    private fun appendLog(message: String) {
        val current = binding.tvLog.text?.toString().orEmpty()
        binding.tvLog.text = if (current.isEmpty()) message else "$current\n$message"
        binding.scrollLog.post {
            binding.scrollLog.fullScroll(android.view.View.FOCUS_DOWN)
        }
    }
}
