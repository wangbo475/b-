package com.bilikuaishou.downloader

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicBoolean

enum class QualityPreset(val label: String) {
    BEST_MP4("最佳画质 (MP4)"),
    HD_1080P("1080P 高清"),
    SD_720P("720P 标清"),
    AUDIO_MP3("仅音频 (MP3)"),
    SUBTITLE_ONLY("仅提取字幕 (SRT)"),
}

object DownloadManager {
    @Volatile
    private var initialized = false

    private val cancelFlag = AtomicBoolean(false)

    const val ACTIVE_PROCESS_ID = "bili_kuaishou_download_task"

    suspend fun ensureInitialized(context: Context) = withContext(Dispatchers.IO) {
        if (!initialized) {
            val appCtx = context.applicationContext
            YoutubeDL.getInstance().init(appCtx)
            FFmpeg.getInstance().init(appCtx)
            initialized = true
        }
    }

    suspend fun updateCore(context: Context): String = withContext(Dispatchers.IO) {
        ensureInitialized(context)
        val status = YoutubeDL.getInstance().updateYoutubeDL(
            context.applicationContext,
            YoutubeDL.UpdateChannel.STABLE,
        )
        when (status) {
            YoutubeDL.UpdateStatus.DONE -> "解析内核已更新到最新版本"
            YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "当前解析内核已是最新版本"
            else -> "内核检查完成"
        }
    }

    fun cancelActiveDownload(): Boolean {
        cancelFlag.set(true)
        return YoutubeDL.getInstance().destroyProcessById(ACTIVE_PROCESS_ID)
    }

    suspend fun downloadVideo(
        context: Context,
        link: ParsedLink,
        quality: QualityPreset,
        downloadPlaylist: Boolean,
        downloadSubtitles: Boolean,
        cookieFilePath: String?,
        onProgress: (progress: Float, etaSeconds: Long, line: String) -> Unit,
    ): List<String> = withContext(Dispatchers.IO) {
        cancelFlag.set(false)

        if (link.platformName == "快手") {
            return@withContext downloadKuaishouVideo(
                context = context,
                link = link,
                subtitleOnly = quality == QualityPreset.SUBTITLE_ONLY,
                saveCaptionText = downloadSubtitles || quality == QualityPreset.SUBTITLE_ONLY,
                onProgress = onProgress,
            )
        }

        ensureInitialized(context)

        val workDir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
            "work_${System.currentTimeMillis()}",
        )
        workDir.mkdirs()

        try {
            val needSubs = downloadSubtitles || quality == QualityPreset.SUBTITLE_ONLY
            val request = YoutubeDLRequest(link.url).apply {
                addOption("-o", File(workDir, "%(title).100B [%(id)s].%(ext)s").absolutePath)
                addOption("--retries", "5")
                addOption("--fragment-retries", "5")
                addOption("--restrict-filenames")
                if (!downloadPlaylist) {
                    addOption("--no-playlist")
                }

                if (needSubs) {
                    addOption("--write-subs")
                    addOption("--write-auto-subs")
                    // 提取所有 CC/AI 字幕并排除弹幕 xml，统一转换为标准 SRT 格式
                    addOption("--sub-langs", "all,-danmaku")
                    addOption("--convert-subs", "srt")
                }

                when (quality) {
                    QualityPreset.BEST_MP4 -> {
                        addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best")
                        addOption("--merge-output-format", "mp4")
                    }
                    QualityPreset.HD_1080P -> {
                        addOption("-f", "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=1080]+bestaudio/best[height<=1080]/best")
                        addOption("--merge-output-format", "mp4")
                    }
                    QualityPreset.SD_720P -> {
                        addOption("-f", "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=720]+bestaudio/best[height<=720]/best")
                        addOption("--merge-output-format", "mp4")
                    }
                    QualityPreset.AUDIO_MP3 -> {
                        addOption("-f", "bestaudio/best")
                        addOption("-x")
                        addOption("--audio-format", "mp3")
                        addOption("--audio-quality", "192K")
                    }
                    QualityPreset.SUBTITLE_ONLY -> {
                        addOption("--skip-download")
                    }
                }

                if (!cookieFilePath.isNullOrBlank() && File(cookieFilePath).exists()) {
                    addOption("--cookies", cookieFilePath)
                }
            }

            YoutubeDL.getInstance().execute(request, ACTIVE_PROCESS_ID) { progress, etaInSeconds, line ->
                onProgress(progress, etaInSeconds, line)
            }

            val producedFiles = workDir.listFiles()
                ?.filter { it.isFile && it.length() > 0L && !it.name.endsWith(".part") }
                .orEmpty()

            if (producedFiles.isEmpty()) {
                if (quality == QualityPreset.SUBTITLE_ONLY) {
                    throw IllegalStateException(
                        "未提取到外挂字幕文件。该视频可能没有 CC/AI 字幕，或 B 站要求先导入已登录的 cookies.txt 才能读取字幕接口"
                    )
                }
                throw IllegalStateException("未找到已生成的媒体文件，请查看日志或检查链接是否需要 Cookie")
            }

            producedFiles.map { file -> publishToPublicDownloads(context, file) }
        } finally {
            workDir.deleteRecursively()
        }
    }

    private suspend fun downloadKuaishouVideo(
        context: Context,
        link: ParsedLink,
        subtitleOnly: Boolean,
        saveCaptionText: Boolean,
        onProgress: (progress: Float, etaSeconds: Long, line: String) -> Unit,
    ): List<String> {
        val workDir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
            "ks_${System.currentTimeMillis()}",
        )
        workDir.mkdirs()

        try {
            val media = KuaishouResolver.resolve(context, link.url) { msg ->
                onProgress(-1f, -1L, msg)
            }
            val savedPaths = mutableListOf<String>()

            if (saveCaptionText) {
                if (media.captionText.isNotBlank()) {
                    val txtFile = File(workDir, "${media.title}_文案.txt")
                    txtFile.writeText(media.captionText, Charsets.UTF_8)
                    savedPaths.add(publishToPublicDownloads(context, txtFile))
                }
                onProgress(
                    -1f,
                    -1L,
                    "[字幕说明] 快手短视频的画面字幕通常直接压制在视频画面中（硬字幕），无独立 CC 字幕轨，已尝试保存作品文案。",
                )
            }

            if (subtitleOnly) {
                if (savedPaths.isEmpty()) {
                    throw IllegalStateException("快手视频无独立外挂 CC 字幕，且未提取到作品文案")
                }
                return savedPaths
            }

            val destFile = File(workDir, "${media.title}.mp4")
            onProgress(0f, -1L, "[快手下载] 正在保存视频：${destFile.name}")
            KuaishouResolver.downloadDirectMp4(
                media = media,
                destFile = destFile,
                isCancelled = { cancelFlag.get() },
            ) { progress, eta ->
                onProgress(progress, eta, "")
            }

            if (!destFile.exists() || destFile.length() == 0L) {
                throw IllegalStateException("快手视频文件为空")
            }
            savedPaths.add(publishToPublicDownloads(context, destFile))
            return savedPaths
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun resolveMimeType(ext: String): String {
        return when (ext) {
            "srt", "vtt", "ass", "lrc", "txt" -> "text/plain"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
    }

    private fun publishToPublicDownloads(context: Context, sourceFile: File): String {
        val ext = sourceFile.extension.lowercase()
        val mimeType = resolveMimeType(ext)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, sourceFile.name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/BiliKuaishou")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法写入系统 Download 目录")

            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
            } ?: throw IllegalStateException("无法打开目标输出流")

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return "Download/BiliKuaishou/${sourceFile.name}"
        } else {
            @Suppress("DEPRECATION")
            val targetDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "BiliKuaishou",
            )
            targetDir.mkdirs()
            val targetFile = File(targetDir, sourceFile.name)
            sourceFile.copyTo(targetFile, overwrite = true)
            return targetFile.absolutePath
        }
    }
}
