package com.bilikuaishou.downloader

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

enum class QualityPreset(val label: String) {
    BEST_MP4("最佳画质 (MP4)"),
    HD_1080P("1080P 高清"),
    SD_720P("720P 标清"),
    AUDIO_MP3("仅音频 (MP3)"),
}

object DownloadManager {
    @Volatile
    private var initialized = false

    const val ACTIVE_PROCESS_ID = "bili_kuaishou_download_task"

    suspend fun ensureInitialized(context: Context) = withContext(Dispatchers.IO) {
        if (!initialized) {
            val appCtx = context.applicationContext
            YoutubeDL.getInstance().init(appCtx)
            FFmpeg.getInstance().init(appCtx)
            initialized = true
        }
    }

    suspend fun updateCore(context: Context): String = withContext(Dispatchers.IO) {
        ensureInitialized(context)
        val status = YoutubeDL.getInstance().updateYoutubeDL(
            context.applicationContext,
            YoutubeDL.UpdateChannel.STABLE,
        )
        when (status) {
            YoutubeDL.UpdateStatus.DONE -> "解析内核已更新到最新版本"
            YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "当前解析内核已是最新版本"
            else -> "内核检查完成"
        }
    }

    fun cancelActiveDownload(): Boolean {
        return YoutubeDL.getInstance().destroyProcessById(ACTIVE_PROCESS_ID)
    }

    suspend fun downloadVideo(
        context: Context,
        link: ParsedLink,
        quality: QualityPreset,
        downloadPlaylist: Boolean,
        cookieFilePath: String?,
        onProgress: (progress: Float, etaSeconds: Long, line: String) -> Unit,
    ): List<String> = withContext(Dispatchers.IO) {
        ensureInitialized(context)

        val workDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "work_${System.currentTimeMillis()}")
        workDir.mkdirs()

        try {
            val request = YoutubeDLRequest(link.url).apply {
                addOption("-o", File(workDir, "%(title).100B [%(id)s].%(ext)s").absolutePath)
                addOption("--retries", "5")
                addOption("--fragment-retries", "5")
                addOption("--restrict-filenames")
                if (!downloadPlaylist) {
                    addOption("--no-playlist")
                }

                when (quality) {
                    QualityPreset.BEST_MP4 -> {
                        addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best")
                        addOption("--merge-output-format", "mp4")
                    }
                    QualityPreset.HD_1080P -> {
                        addOption("-f", "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=1080]+bestaudio/best[height<=1080]/best")
                        addOption("--merge-output-format", "mp4")
                    }
                    QualityPreset.SD_720P -> {
                        addOption("-f", "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=720]+bestaudio/best[height<=720]/best")
                        addOption("--merge-output-format", "mp4")
                    }
                    QualityPreset.AUDIO_MP3 -> {
                        addOption("-f", "bestaudio/best")
                        addOption("-x")
                        addOption("--audio-format", "mp3")
                        addOption("--audio-quality", "192K")
                    }
                }

                if (!cookieFilePath.isNullOrBlank() && File(cookieFilePath).exists()) {
                    addOption("--cookies", cookieFilePath)
                }
            }

            YoutubeDL.getInstance().execute(request, ACTIVE_PROCESS_ID) { progress, etaInSeconds, line ->
                onProgress(progress, etaInSeconds, line)
            }

            val producedFiles = workDir.listFiles()
                ?.filter { it.isFile && it.length() > 0L && !it.name.endsWith(".part") }
                .orEmpty()

            if (producedFiles.isEmpty()) {
                throw IllegalStateException("未找到已生成的媒体文件，请查看日志或检查链接是否需要 Cookie")
            }

            val savedNames = mutableListOf<String>()
            for (file in producedFiles) {
                val publishedName = publishToPublicDownloads(context, file)
                savedNames.add(publishedName)
            }
            savedNames
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun publishToPublicDownloads(context: Context, sourceFile: File): String {
        val ext = sourceFile.extension.lowercase()
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (ext == "mp3") "audio/mpeg" else "video/mp4"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, sourceFile.name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/BiliKuaishou")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法写入系统 Download 目录")

            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
            } ?: throw IllegalStateException("无法打开目标输出流")

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return "Download/BiliKuaishou/${sourceFile.name}"
        } else {
            @Suppress("DEPRECATION")
            val targetDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "BiliKuaishou",
            )
            targetDir.mkdirs()
            val targetFile = File(targetDir, sourceFile.name)
            sourceFile.copyTo(targetFile, overwrite = true)
            return targetFile.absolutePath
        }
    }
}
