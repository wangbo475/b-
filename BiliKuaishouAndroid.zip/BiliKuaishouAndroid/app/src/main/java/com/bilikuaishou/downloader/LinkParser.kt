package com.bilikuaishou.downloader

data class ParsedLink(
    val url: String,
    val platformName: String,
)

object LinkParser {
    private val urlRegex = Regex(
        pattern = "https?://[^\\s<>\"'\\]】）），。！？；、]+",
        option = RegexOption.IGNORE_CASE,
    )
    private val bvRegex = Regex("\\b(BV[0-9A-Za-z]{10})\\b")
    private val avRegex = Regex("\\b(av\\d+)\\b", RegexOption.IGNORE_CASE)

    private val trailingPunctuation = setOf(
        '.', ',', ';', ':', '!', '?', ')', ']', '}',
        '》', '」', '』', '】', '）', '，', '。', '！', '？', '；', '、', '"', '\''
    )

    private val bilibiliDomains = listOf(
        "bilibili.com",
        "b23.tv",
        "bili2233.cn",
        "acg.tv",
    )

    private val kuaishouDomains = listOf(
        "kuaishou.com",
        "chenzhongtech.com",
        "gifshow.com",
        "kwai.com",
    )

    fun cleanUrl(rawUrl: String): String {
        var result = rawUrl.trim()
        while (result.isNotEmpty() && result.last() in trailingPunctuation) {
            result = result.dropLast(1)
        }
        return result
    }

    fun detectPlatform(url: String): String {
        val lower = url.lowercase()
        return when {
            bilibiliDomains.any { lower.contains(it) } -> "B站"
            kuaishouDomains.any { lower.contains(it) } -> "快手"
            else -> "其他平台"
        }
    }

    fun extractLinks(rawText: String): List<ParsedLink> {
        val seen = LinkedHashSet<String>()
        val results = mutableListOf<ParsedLink>()

        fun addCandidate(candidate: String) {
            val cleaned = cleanUrl(candidate)
            if (cleaned.isNotEmpty() && seen.add(cleaned)) {
                results.add(ParsedLink(url = cleaned, platformName = detectPlatform(cleaned)))
            }
        }

        urlRegex.findAll(rawText).forEach { match ->
            addCandidate(match.value)
        }

        val withoutUrls = urlRegex.replace(rawText, " ")
        bvRegex.findAll(withoutUrls).forEach { match ->
            addCandidate("https://www.bilibili.com/video/${match.groupValues[1]}")
        }
        avRegex.findAll(withoutUrls).forEach { match ->
            addCandidate("https://www.bilibili.com/video/${match.groupValues[1].lowercase()}")
        }

        return results
    }
}
